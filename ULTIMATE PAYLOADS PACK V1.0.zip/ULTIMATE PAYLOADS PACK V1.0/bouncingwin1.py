from time import sleep
from tkinter import *

class Window(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.width = 300
        self.height = 300
        self.velx = 1
        self.vely = 1
        self.pos = (250,250)
        self.geometry(f"{self.width}x{self.height}+{self.pos[0]}+{self.pos[1]}")

    def moveWin(self):
        x = self.pos[0] + self.velx
        y = self.pos[1] + self.vely
        downx, downy = x+self.width, y+self.height
        sWidth = self.winfo_screenwidth()  # gives 1366
        sHeight = self.winfo_screenheight()  # gives 1080
        if x <= 0 or downx >= sWidth:
            self.velx = -self.velx
        if y <= 0 or downy >= sHeight:
            self.vely = -self.vely
        self.pos = (x,y)
        self.geometry(f"+{x}+{y}")
        return [x, y, downx, downy]

root = Window()
while True:
    root.update()
    pos = root.moveWin()
    print(pos)
    sleep(0.00)
