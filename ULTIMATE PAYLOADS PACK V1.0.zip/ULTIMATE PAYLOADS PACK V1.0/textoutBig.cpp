#include <windows.h>

int main() {
    int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
    LPCSTR text = 0;
    while (1)
    {
        HDC hdc = GetDC(0);
        SetBkMode(hdc, 0);
        text = "POU HACKEO TU PC XD";
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        HFONT font = CreateFontA(43, 32, 0, 0, FW_THIN, 0, 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Comic Sans MS");
        SelectObject(hdc, font);
        TextOutA(hdc, rand() % x, rand() % y, text, strlen(text));
        Sleep(100);
        DeleteObject(font);
        ReleaseDC(0, hdc);
    }
}